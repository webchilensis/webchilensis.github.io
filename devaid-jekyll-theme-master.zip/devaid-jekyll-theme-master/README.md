devAid theme from Xiaoying Riley, adopted to Jekyll

early stage, pls open issue if you need any updates

[Download](https://github.com/kevit/devaid-jekyll-theme/blob/master/archive.tar.bz2).

[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/kevit/devaid-jekyll-theme/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

